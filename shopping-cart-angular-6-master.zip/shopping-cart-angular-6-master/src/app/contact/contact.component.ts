import { Component, OnInit, ElementRef } from '@angular/core';
declare let $: any;
declare let swal: any; 
import * as $ from 'jquery';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
     
    $(function () {
      //alert(); 
      $('.getCartVal').on('click', function () {
       var productPrice = $(this).parent().parent().parent().find('.block2-price').text();
       var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
      //  var nameProduct = $(this).parent().parent().parent().find('.block2-name')();
        console.log(nameProduct,"=",productPrice); 
        swal(nameProduct, "is added to cart !", "success");
      });
    })

  }
  ngAfterViewInit() {
    var jquery2 = document.createElement('script');
    jquery2.type = "text/javascript";
    jquery2.src = "../assets/vendor/animsition/js/animsition.min.js";
    this.elementRef.nativeElement.appendChild(jquery2);

    var jquery3 = document.createElement('script');
    jquery3.type = "text/javascript";
    jquery3.src = "../assets/vendor/jquery/jquery-3.2.1.min.js";
    this.elementRef.nativeElement.appendChild(jquery3);

    var jquery = document.createElement('script');
    jquery.type = "text/javascript";
    jquery.src = "../assets/js/main.js";
    this.elementRef.nativeElement.appendChild(jquery);

    var slick = document.createElement('script');
    slick.type = "text/javascript";
    slick.src = "../assets/vendor/slick/slick.min.js";
    this.elementRef.nativeElement.appendChild(slick);

    var select2 = document.createElement('script');
    select2.type = "text/javascript";
    select2.src = "../assets/vendor/select2/select2.min.js";
    this.elementRef.nativeElement.appendChild(select2);

  }

}
