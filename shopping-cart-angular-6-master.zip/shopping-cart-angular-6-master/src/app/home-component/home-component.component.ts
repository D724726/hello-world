import { Component, OnInit, ElementRef } from '@angular/core';
declare let $: any;
declare let swal: any;
import * as $ from 'jquery';
import{ HeaderComponent} from "../layout/header/header.component"

@Component({
  selector: 'app-home-component',
  providers:[HeaderComponent ],
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css']
})

export class HomeComponentComponent implements OnInit {
  productArr: any = [];
  public name:any="dkajshdsajhakjhdlkjahd";
  // productArr: any ={};
  constructor(private elementRef: ElementRef,private header:HeaderComponent) { }

  ngOnInit() {

  }
  getProductInfo(iNo: any, productId: any, nameProduct: any, productPrice: any, img: any) {
    // alert();

    if (JSON.parse(localStorage.getItem('cart'))) {
      this.productArr = JSON.parse(localStorage.getItem('cart'));
    }

    // console.log(this.lookup(productId))
    if (this.lookup(productId) == true) {

      var totalCart = JSON.parse(window.localStorage.getItem('cart'));
      for (var k in totalCart) {
       
        if (totalCart[k]['productId'] == productId) {
          totalCart[k]['quantity'] = totalCart[k]['quantity'] + 1;
          totalCart[k]['productPrice'] = parseInt(totalCart[k]['productPrice']) + parseInt(productPrice);
          // console.log('fkjhbdskjf');
          window.localStorage.setItem('cart', JSON.stringify(totalCart));
          break;
        }
      }
      
    

    } else {
      var arrt = {
        productId: $.trim(productId),
        nameProduct: $.trim(nameProduct),
        productPrice: $.trim(productPrice),
        productSinglePrice: $.trim(productPrice),
        img: $.trim(img),
        quantity: 1
      }
      // this.productArr[iNo]=arrt;
      this.productArr.push(arrt);
      //console.log(this.productArr);
      
      window.localStorage.setItem('cart', JSON.stringify(this.productArr));
    }
    this.header.getCartItem();
    swal(nameProduct, "is added to cart !", "success");
  }
  
  lookup(productId) {
    var getCart = JSON.parse(window.localStorage.getItem('cart'));
    /*  for(var k in getCart) {
    // console.log(getCart[k]['productId'],'==', productId);
       if (getCart[k]['productId']== productId) {
         return true;
       }
   } */
    // console.log(getCart);
    if (getCart != null) {
      for (let i = 0; i < getCart.length; i++) {
        if (getCart[i]['productId'] == productId) {
          return true;
        }
      }
    }
    return false;
  }
  ngAfterViewInit() {
    var jquery2 = document.createElement('script');
    jquery2.type = "text/javascript";
    jquery2.src = "../assets/vendor/animsition/js/animsition.min.js";
    this.elementRef.nativeElement.appendChild(jquery2);

    var jquery3 = document.createElement('script');
    jquery3.type = "text/javascript";
    jquery3.src = "../assets/vendor/jquery/jquery-3.2.1.min.js";
    this.elementRef.nativeElement.appendChild(jquery3);

    var jquery = document.createElement('script');
    jquery.type = "text/javascript";
    jquery.src = "../assets/js/main.js";
    this.elementRef.nativeElement.appendChild(jquery);

    var jquery1 = document.createElement('script');
    jquery1.type = "text/javascript";
    jquery1.src = "../assets/vendor/slick/slick.min.js";
    this.elementRef.nativeElement.appendChild(jquery1);
    
  }
 


}
