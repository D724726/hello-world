import { Component, OnInit, Input } from '@angular/core';
import {Router} from "@angular/router"
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  totalItems: any = [];
  totcatProCnt: any ;
  totalP:number;
  @Input() public parentData;
  constructor(private router: Router) { }

  ngOnInit() {
   this. getCartItem();
  }

  getCartItem() {
   // alert();
    var totalCart = JSON.parse(localStorage.getItem('cart'));
    if(totalCart){
      this.totcatProCnt=totalCart.length;
      this.totalP=this.totalPrice();
      this.totalItems = totalCart;
    }else{
      this.totcatProCnt=0;
      this.totalP=0;
      this.totalItems ='';
    }
  
    //this.ngOnInit();
  }

  totalPrice() {
    // alert(value);
    var totalCart = JSON.parse(localStorage.getItem('cart'));
    let totalPrice=0;
    for (var k in totalCart) {
     totalPrice+=parseInt(totalCart[k]['productPrice']); 
    }
    return totalPrice;
  }

  removeItems(productId) {
    // alert(value);
    var totalCart = JSON.parse(localStorage.getItem('cart'));
    this.totalItems = this.removeFromCart(totalCart, productId);
    
    if(totalCart.length===0)
    {
      // console.log(totalCart.length);
      this.router.navigate(['/product'])
    }
    this.ngOnInit();
  }

  removeFromCart(totalCart, productId) {
    
    for (var k in totalCart) {
     // console.log(k, totalCart[k]['productId'], '==', productId);
      if (totalCart[k]['productId'] == productId) {
        totalCart.splice(k, 1); //first paramiter wich position and 2nd how many array remove
      }
    }
    this.totalItems = totalCart;
    window.localStorage.setItem('cart', JSON.stringify(totalCart));
    
  }

}
