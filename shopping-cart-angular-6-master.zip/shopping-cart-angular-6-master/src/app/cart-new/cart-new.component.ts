import { Component, OnInit,ElementRef } from '@angular/core';

@Component({
  selector: 'app-cart-new',
  templateUrl: './cart-new.component.html',
  styleUrls: ['./cart-new.component.css']
})
export class CartNewComponent implements OnInit {
  totalCartItems:any;
  totalCartPrice:number=0;
  constructor(private elementRef:ElementRef) { }

  ngOnInit() {
    var cartItems=JSON.parse(localStorage.getItem('cart'));
    this.totalCartItems=cartItems;
    for (var k in cartItems) {
      this.totalCartPrice+=parseInt(cartItems[k]['productPrice']);
    }
      
  }
  public counter : number = 1;
    
  increment(thisobj){
    //console.log(thisobj);
    var totalCart = JSON.parse(window.localStorage.getItem('cart'));
    for (var k in totalCart) {

      if (totalCart[k]['productId'] == thisobj.productId) {
          totalCart[k]['quantity'] = totalCart[k]['quantity'] + 1;
          totalCart[k]['productPrice'] = parseInt(totalCart[k]['productPrice']) + parseInt(totalCart[k]['productSinglePrice']);
          // console.log('fkjhbdskjf');

          window.localStorage.setItem('cart', JSON.stringify(totalCart));
          break;
      }
     
  }
    if(this.counter>=1){
      thisobj.quantity += 1; 
      thisobj.productPrice += parseInt(thisobj.productSinglePrice); 

    } 
  }
  
  decrement(thisArray){
    var totalCart = JSON.parse(window.localStorage.getItem('cart'));
           
    for (var k in totalCart) {

        if (totalCart[k]['productId'] == thisArray.productId) {
            totalCart[k]['quantity'] = totalCart[k]['quantity'] - 1;
            totalCart[k]['productPrice'] = parseInt(totalCart[k]['productPrice']) - parseInt(totalCart[k]['productSinglePrice']);
            // console.log('fkjhbdskjf');

            window.localStorage.setItem('cart', JSON.stringify(totalCart));
            break;
        }
       
    }
    if(thisArray.quantity >1){
      thisArray.quantity -= 1; 
      thisArray.productPrice -= parseInt(thisArray.productSinglePrice); 

    } 
  }

  
  ngAfterViewInit() {
    var jquery2 = document.createElement('script');
    jquery2.type = "text/javascript";
    jquery2.src = "../assets/vendor/animsition/js/animsition.min.js";
    this.elementRef.nativeElement.appendChild(jquery2);

    var jquery3 = document.createElement('script');
    jquery3.type = "text/javascript";
    jquery3.src = "../assets/vendor/jquery/jquery-3.2.1.min.js";
    this.elementRef.nativeElement.appendChild(jquery3);

    var jquery = document.createElement('script');
    jquery.type = "text/javascript";
    jquery.src = "../assets/js/main.js";
    this.elementRef.nativeElement.appendChild(jquery);

  }
  }


