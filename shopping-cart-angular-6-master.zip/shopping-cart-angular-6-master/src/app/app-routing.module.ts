import { NgModule } from '@angular/core';
//import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponentComponent } from './home-component/home-component.component';
import { AboutComponent } from './about/about.component';
import { ProductComponent } from './product/product.component';
import { CartComponent } from './cart/cart.component';
import { ContactComponent } from './contact/contact.component';
import { CartNewComponent } from './cart-new/cart-new.component';
import { AuthGuardGuard } from './auth-guard.guard';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path: 'home',
    data: { title: "Home Page" ,
     // canActivate:[AuthGuardGuard],
    description:'Home Description Meta Tag Content',
    keyword:'Home Description, Meta, Tag, Content',
   },
    
    component: HomeComponentComponent
  },
  {
    path: 'about',
    data: { title: "About Page",
    description:'about Description Meta Tag Content',
    keyword:'about Description, Meta, Tag, Content', },
    // canActivate:[AuthGuardGuard],
    component: AboutComponent
  },
  {
    path: 'product',
    data: { title: "Product Page",
    description:'product Description Meta Tag Content',
    keyword:'product Description, Meta, Tag, Content', },
    component: ProductComponent
  },
  {
    path: 'cart',
    data: { title: "Cart Page" ,
    description:'cart Description Meta Tag Content',
    canActivate:[AuthGuardGuard],
    keyword:'cart Description, Meta, Tag, Content',},
    component: CartComponent
  },
  {
    path: 'contact',
    data: { title: "Contact Page",
    description:'contact Description Meta Tag Content',
    keyword:'contact Description, Meta, Tag, Content', },
    component: ContactComponent
  },
  {
    path: 'cart-new',
    data: { title: "Cart-new Page" ,
    description:'cart-new Description Meta Tag Content',
    keyword:'cart-new Description, Meta, Tag, Content',},
    component: CartNewComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
