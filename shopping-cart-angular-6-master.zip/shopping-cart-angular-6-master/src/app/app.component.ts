import { Component } from '@angular/core';
import { Title ,Meta } from '@angular/platform-browser';
import { filter, map, mergeMap } from 'rxjs/operators';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-dream-app';
  constructor(
    private router: Router,
    public activatedRoute: ActivatedRoute,
    public titleService: Title,
    private meta: Meta
  ) { }



  ngOnInit() {
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd),
      map(() => this.activatedRoute),
      map((route) => {
        while (route.firstChild) {
          route = route.firstChild;
        };

        return route;
      }),
      filter((route) => route.outlet === 'primary'),
      mergeMap((route) => route.data),
    ).subscribe((event) => {
      this.titleService.setTitle("My App | "+event['title']);
      this.meta.updateTag({ name: 'description', content: event['description'] })
      this.meta.updateTag({ name: 'keyword', content: event['keyword'] })
    });
  }


}
