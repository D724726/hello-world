import { Component, OnInit,ElementRef } from '@angular/core';
declare let $: any;
declare let swal: any; 
import * as $ from 'jquery';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
totalCartItems:any;
totalItems:any;
totalCartPrice:number=0;
  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
    var cartItems=JSON.parse(localStorage.getItem('cart'));
    this.totalCartItems=cartItems;
    for (var k in cartItems) {
      this.totalCartPrice+=parseInt(cartItems[k]['productPrice']);
    }
      
  }
  /* removeItems(productId) {
    // alert(productId);
    var totalCart = JSON.parse(localStorage.getItem('cart'));
    this.totalCartItems = this.removeFromCart(totalCart, productId);
    //console.log(this.totalItems);
    this.ngOnInit();
  }
  removeFromCart(totalCart, productId) {
    
    for (var k in totalCart) {
     // console.log(k, totalCart[k]['productId'], '==', productId);
      if (totalCart[k]['productId'] == productId) {
        totalCart.splice(k, 1); //first paramiter wich position and 2nd how many array remove
      }
    }
   
    this.totalCartItems = totalCart;
    window.localStorage.setItem('cart', JSON.stringify(totalCart));
    
  } */

  ngAfterViewInit() {
    var jquery2 = document.createElement('script');
    jquery2.type = "text/javascript";
    jquery2.src = "../assets/vendor/animsition/js/animsition.min.js";
    this.elementRef.nativeElement.appendChild(jquery2);

    var jquery3 = document.createElement('script');
    jquery3.type = "text/javascript";
    jquery3.src = "../assets/vendor/jquery/jquery-3.2.1.min.js";
    this.elementRef.nativeElement.appendChild(jquery3);

    var jquery = document.createElement('script');
    jquery.type = "text/javascript";
    jquery.src = "../assets/js/main.js";
    this.elementRef.nativeElement.appendChild(jquery);

    var slick = document.createElement('script');
    slick.type = "text/javascript";
    slick.src = "../assets/vendor/slick/slick.min.js";
    this.elementRef.nativeElement.appendChild(slick);

    var select2 = document.createElement('script');
    select2.type = "text/javascript";
    select2.src = "../assets/vendor/select2/select2.min.js";
    this.elementRef.nativeElement.appendChild(select2);

  }

}
